function openModal() {
  document.getElementById('calendarModal').style.display = 'flex';
}

function closeModal() {
  document.getElementById('calendarModal').style.display = 'none';
}
